# FB - Search FB group data export

### This extension allows the user to export fb group search data

### Developed by ohmygodvt95